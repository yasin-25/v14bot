# V14 Ertu - Crane Bots (Piyasanin En İyisi)
Ertu - Crane gelişmiş Pm2 V14 Botlarıdır
<a href="#napirs">@napi-rs/canvas Hatası Alıyorsan Buraya Tıkla!</a>

Emeği geçen **CRANE, vante, piku, beş, lulu, approval, luhux, relivent, arwen ve cartel**'e tesekkürler <3

Projenin ücretli satılması veya başkası tarafından başka bir ad ile dağıtılması kesinlikle yasaktır. Proje lisanslı bir projedir, bu tarz işlemlerde bulunanlar olursa lisans aracılığı ile gerekli yasal yollara başvurulacaktır.

### Sahip Komutları
<details>
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/76b9de4a-b38a-496e-a2fd-443fff2fec9c">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/52e97829-92ba-49d7-8637-a23b1719affb">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/0936c1e1-0d45-45db-8873-f1a9988d269a">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/31f41c70-ec25-486f-b65d-2c0a58716d4b">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/e6b78a7b-b870-42d2-bc21-32fac6122692" title="Select menülü knk ya cok zor"> (Select menülü knk ya cok zor)
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/8fc7f247-c776-4bdf-9928-8ae99947f8dd">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/e2ca4d29-3d13-440c-8924-02cadde4a870">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/abaf7b95-2e51-4e9c-88d9-6320e366487d">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/0e208275-e5e8-45fe-9323-dadd616f34aa">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/94e99a06-6cec-423c-b5e8-1db6d0c4fe4a">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/310ddea2-8c93-4bbf-ab48-34e1fd9a0084">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/68b686da-1e04-4825-8916-7db45b2c54d7">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/649b63c5-40c9-47e9-8fa3-64a7f497e55c">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/7822202c-d5c9-4bdc-aa56-6b6c5f396fc1">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/07301341-d1ae-478a-9a88-74b0f1475518">
</details>

### Kurucu Komutları
<details>
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/020efc3a-61d1-418c-8a7c-ba8a8e87156d">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/d3e10eae-eabb-46e5-acd1-c005dcc10d14">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/5f2b9f25-be18-4a20-99be-81899eb5611a">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/e7144d2d-6afd-4747-92c3-e3e8388f106b">
</details>

### Yetkili Komutları
<details>
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/b9706281-3118-477c-8c21-320dc564f43c">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/4886cd77-3d25-47f7-93fe-8f216b32dbf6">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/9adcddf2-b932-4261-8ac6-734fc4ec1efa">
</details>
  
### Stat Komutları
<details>
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/4704cd47-aefe-4849-a9a7-a66d0ff63829">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/2833431d-b2c1-4b69-8ff4-67f15b339abf">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/cf73cc10-c640-4ee5-bcbc-baaee231146b">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/462d4e2a-e676-453f-9791-1fc1ac7d56ec">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/0efc8a5d-bf7a-459b-b03d-ac8eb41427a0">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/a1bbd0cd-59fc-4020-bb52-6430e4c35e61">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/be2b5ae3-a208-40aa-85d3-683b6bba06c7">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/8b064bfc-1170-4900-86b1-866c6a46f0a2">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/583e7685-9485-4d5d-a616-72cabff6d0d6">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/5a6bba46-0137-4bc8-b0eb-d879f1ccecbd">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/7819dc34-002d-4a0b-8f12-a7e09379782f">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/fc467640-5df4-4d4c-8a32-ccd5bc376460">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/08b87a9e-5a16-40ac-b86c-b3877ce44e85">
</details>

### Rank Komutları
<details>
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/d7096474-3d5e-4a16-a39f-225e38dc3c5a">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/f63c693e-218e-4565-86b7-745ef0be5ede">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/68e29151-7856-4843-b0e8-100d0c8ae3e9">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/fe797be8-7da6-4c57-bc2a-82bf14e7a77f">
</details>


### Kayıt Komutları
<details>
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/d6b2d03f-4fcd-48de-a505-924dc4a3fecd">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/68016563-db04-45b5-9f61-cb8cfd6066ee">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/04c183ba-2563-454c-af1e-82ed8b934c7e">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/b6f42c07-1bd0-4200-b882-caec95192704">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/30cd0a59-e16a-4ca6-aae0-55dc2c94a736">
</details>

### Ceza Komutları
<details>
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/10d548aa-0f9e-4564-8659-97b58ee18f67">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/f29359ce-1aa1-4990-adb8-18919a6f5f81">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/1df0e376-b5fd-4557-9e92-ce30e5d765bb">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/26a7102a-b450-4126-b539-883df76aa66d">
</details>


### Kullanıcı Komutları 
<details>
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/405a6bd4-4492-4183-a015-b161e2bfaf56">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/3e523a15-1fdb-4486-b23c-2216daf02c7b">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/b3f95e95-d250-4fe1-94ba-46928ad6f2e0">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/3e2d228e-a1b3-4b33-9ff0-24833e89ea9f">
  <img src="https://github.com/ertucuk/Discord-Bots-V14/assets/68440024/66824041-46f2-4013-b6ed-106fdd71a292">
</details>


<h1>⚠️ @napi-rs/canvas Hatası</h1>
<h2 id="napirs">Hatanın msvc'den Kaynaklı Alttaki Linkten Gerekli Driver'ları Kurabilirsiniz.</h2>
<img src="https://cdn.discordapp.com/attachments/950167988127006821/1111440762438172773/2023-05-26_02-45-14.png">
<a href="https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170">Gerekli Driver</a> Yüklendikten Sonra Makinenizi/Bilgisayarınızı Yeniden Başlatınız.
