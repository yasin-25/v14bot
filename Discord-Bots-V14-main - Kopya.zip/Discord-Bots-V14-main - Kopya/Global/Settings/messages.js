module.exports = {// buraya dokunmayiniz
    giveaway: `🎉 Çekiliş Başladı!`,
    giveawayEnded:`🎉 Çekiliş Sona Erdi!`,
    noWinner: `Kazanan Bulunmamakta!`,
    winMessage:`🎉 Çekiliş Bitti!\n Kazanan(lar): {winners}\n{this.messageURL}`,
    title: '{this.prize}',
    inviteToParticipate: 'Katılmak İçin 🎉 Tepkisine Basın',
    drawing: 'Kalan Süre: {timestamp}',
    dropMessage: 'İlk Tepkiye Basan Sen Ol 🎉!',
    embedFooter: '{this.winnerCount} Kazanan',
    winners: 'Kazanan:',
    endedAt: 'Çekiliş Bitti',
    hostedBy: 'Başlatan: {this.hostedBy}',
    }