module.exports = {// buraya dokunmayiniz!!!!!!!!!!!!!!!!
    mp3: true, 
    file: "./ertu.mp3", 
    youtubeURL: "https://www.youtube.com/watch?v=dQw4w9WgXcQ&ab_channel=RickAstley"
  }